from django.apps import AppConfig


class ProtestConfig(AppConfig):
    name = 'Protest'
