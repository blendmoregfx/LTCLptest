from django.conf import settings
from django.contrib.auth.decorators import login_required
from django.shortcuts import render, redirect
from django.http import HttpResponse, JsonResponse
User = settings.AUTH_USER_MODEL
# Create your views here.JsonResponse

from .forms import QuestionandanswersForm
from .models import ProenglishQuestionsandanswers, SwahiliQuestionandanswers, EnglishGradiTable
from .models import RegisterEnglishTable, FrenchQuestionandanswers, MandarinQuestionandanswers
from .models import BookATestTable, StoreScore

@login_required
def goHomepage(request):
    return render(request, 'Protest/home.html')

def index(request):
    return render(request, 'Protest/landingpage.html')

@login_required
def AddQuestionLandingPage(request):
    return render(request, 'Protest/addqlandingpage.html')

#Add English Questions and Answers
@login_required
def AddEnglishQuestionAnsAnswer(request):
    if request.method == 'POST':
        form = QuestionandanswersForm(request.POST)
        if form.is_valid():
            newQuestion = ProenglishQuestionsandanswers.objects.create(language=request.POST['language'], section=request.POST['section'],
                          questionNumber=request.POST['questionNumber'], question=request.POST['question'],
                          AnsA=request.POST['AnsA'], AnsB=request.POST['AnsB'],AnsC=request.POST['AnsC'],AnsD=request.POST['AnsD'],
                          rightAnswer=request.POST['rightAnswer'], questionHead=request.POST['questionHead'])
            return redirect('/showenquestion/%s' % newQuestion.id)
    form = QuestionandanswersForm
    context = {'form' : form }
    return render(request, 'Protest/addenquestionandanswer.html', context)

#some Eng validation: checks if number exists.
def validate_Question_Number(request):
    questionNumber = request.GET.get('Qnumber', None)
    data = {
        'num_exist': ProenglishQuestionsandanswers.objects.filter(questionNumber__iexact=questionNumber).exists()
    }
    print(questionNumber)
    return JsonResponse(data)

@login_required
def ShowEngQuesion(request, enq_id):
    getengQuestion = ProenglishQuestionsandanswers.objects.get(pk=enq_id)
    context = {'getengQuestion' : getengQuestion}
    return render(request, 'Protest/showengqa.html', context)

@login_required
def TakeEnglishTestGrammar1(request):
    getQa = ProenglishQuestionsandanswers.objects.filter(language="English", section="Grammar1")
    title = "Take English Test"
    context = {'getQa' : getQa, 'title' : title}
    return render(request, 'Protest/takeEngtest.html', context)

@login_required
def TakeEnglishTestGrammar2(request):
    getQa = ProenglishQuestionsandanswers.objects.filter(language="English", section="Grammar2")
    title = "Take English Test"
    context = {'getQa' : getQa, 'title' : title}
    return render(request, 'Protest/takeEngtest.html', context)

@login_required
def EngREadingCompreh(request):
    getQa = ProenglishQuestionsandanswers.objects.filter(language="English", section="READING COMPREHENSION")
    title = "Take English Test"
    context = {'getQa' : getQa, 'title' : title}
    return render(request, 'Protest/takeEngtest.html', context)

@login_required
def TakeEngSynonyms(request):
    getQa = ProenglishQuestionsandanswers.objects.filter(language="English", section="SYNONYMS")
    title = "Take English Test"
    context = {'getQa' : getQa, 'title' : title}
    return render(request, 'Protest/takeEngtest.html', context)

@login_required
def TakeEngAntonyms(request):
    getQa = ProenglishQuestionsandanswers.objects.filter(language="English", section="Antonyms")
    title = "Take English Test"
    context = {'getQa' : getQa, 'title' : title}
    return render(request, 'Protest/takeEngtest.html', context)

@login_required
def TakeEngVocaublary(request):
    getQa = ProenglishQuestionsandanswers.objects.filter(language="English", section="Vocabulary")
    title = "Take English Test"
    context = {'getQa' : getQa, 'title' : title}
    return render(request, 'Protest/takeEngtest.html', context)


@login_required
def TakeEngPartsofSpeech(request):
    getQa = ProenglishQuestionsandanswers.objects.filter(language="English", section="Parts of Speech")
    title = "Take English Test"
    context = {'getQa' : getQa, 'title' : title}
    return render(request, 'Protest/takeEngtest.html', context)


@login_required
def GradeEngish(request):
    if request.is_ajax and request.POST:
       #The engQID will hold questionNumber not its ID
       getSelID = request.POST.get('engQID')
       getAnsV = request.POST.get('getansValue')
    logduser = request.user.username
    logduseremail = request.user.email
    findEngQaA = ProenglishQuestionsandanswers.objects.get(questionNumber=getSelID)

    saveChoice = EnglishGradiTable(language=findEngQaA.language, section=findEngQaA.section, questionNumber=findEngQaA.questionNumber,
                 question=findEngQaA.question, AnsA=findEngQaA.AnsA, AnsB=findEngQaA.AnsB, AnsC=findEngQaA.AnsC,
                 AnsD=findEngQaA.AnsD, rightAnswer=findEngQaA.rightAnswer, selectedAns=getAnsV, userId=logduser,
                 userEmail=logduseremail)
    saveChoice.save()

    getSavedChoice = EnglishGradiTable.objects.filter(questionNumber=getSelID, userEmail=logduseremail).count()
    if getSavedChoice > 1:
        EnglishGradiTable.objects.filter(questionNumber=getSelID, userEmail=logduseremail).delete()
    saveChoice.save()
    print(saveChoice.selectedAns)
    #for testing purposes only, please delete this when done
    recountEntries = EnglishGradiTable.objects.filter(questionNumber=getSelID, userEmail=logduseremail).count()
    print(recountEntries)

    compareAns = EnglishGradiTable.objects.filter(userEmail=logduseremail, questionNumber=getSelID, username=logduser, language="English")
    if compareAns.selectedAns == compareAns.rightAnswer:
        saveScore = StoreScore(email=logduseremail, username=logduser, questionNumber=getSelID, language="English", score=1)
        saveScore.save()
    checkScore = StoreScore.objects.filter(email=logduseremail, username=logduser, questionNumber=getSelID).count()
    if checkScore > 1 and compareAns.selectedAns == compareAns.rightAnswer:
        StoreScore.objects.filter(email=logduseremail, username=logduser, questionNumber=getSelID).delete()
        saveScore.save()

    BookATestTable.objects.filter(email=logduseremail, username=logduser, language="English").update(attempted=1)
    countTesAttmptEntries = BookATestTable.objects.filter(email=logduseremail, username=logduser, language="English", attempted=1).count()
    print(countTesAttmptEntries)
    if countTesAttmptEntries > 1:
        BookATestTable.objects.filter(email=logduseremail, username=logduser).update(attempted=1).delete()
        BookATestTable.objects.filter(email=logduseremail, username=logduser, language="English").update(attempted=1)



    return JsonResponse(getSelID, safe=False)

@login_required
def EnglishScoregrm1(request):
    title = "Take English Test"
    lang = "English"
    logduser = request.user.username
    logduseremail = request.user.email
    engScore = EnglishGradiTable.objects.filter(userId=logduser).order_by('questionNumber')
    getScore = StoreScore.objects.filter(email=logduseremail, username=logduser, language="English").count()
    context = {'title' : title, 'engScore' : engScore, 'lang' : lang, 'getScore' : getScore}
    return render(request, 'Protest/englishscoreGRM1.html', context)

@login_required
def EnglishScoregrm2(request):
    title = "Take English Test"
    lang = "English"
    logduser = request.user.username
    logduseremail = request.user.email
    engScore = EnglishGradiTable.objects.filter(userId=logduser).order_by('questionNumber')
    getScore = StoreScore.objects.filter(email=logduseremail, username=logduser, language="English").count()
    context = {'title' : title, 'engScore' : engScore, 'lang' : lang, 'getScore' : getScore}
    return render(request, 'Protest/englishscoreGRM2.html', context)

@login_required
def StudentDashboard(request):
    return render(request, 'Protest/stddashboard.html')

# @login_required
# def TestLinks(request):
#     logduser = request.user.username
#     availabletest = BookATestTable.objects.filter(username=logduser, Available="Yes", language="English")
#     getAvailstatus = availabletest.Available
#     context = {'availabletest' : availabletest}
#     return render(request,  'Protest/testlinkpage.html', context)

@login_required
def BookAssessment(request):
    title = "Book Assessment"
    header = "All Assessments test should be booked here"
    context = {'title' : title, 'header': header}
    return render(request, 'Protest/bookassment.html', context)

@login_required
def AvailableTest(request):
    logedin_User = request.user.username
    availabletest = BookATestTable.objects.filter(username=logedin_User, Available="Yes")
    title = "Available Tests"
    context = {'title': title, 'availabletest':availabletest}
    return render(request, 'Protest/availabletest.html', context)

#this function will render a page with all available assessment languages and page with its quesions and answers
def GetAvailalbeTest(request):
    return render(request, 'Protest/linktoavialbleqa.html')

@login_required
def ViewAssResults(request):
    getuser = request.user.username
    logduseremail = request.user.email
    getResults = BookATestTable.objects.filter(username=getuser, language="English")
    getScore = StoreScore.objects.filter(email=logduseremail, username=getuser, language="English").count()
    title = "View Assessment results"
    context = {'title': title, 'getResults':getResults, 'getScore':getScore}
    return render(request, 'Protest/viewassementresult.html', context)

@login_required
def BookAtest(request):
    if request.is_ajax and request.POST:
        getbkchoice = request.POST.get('getchoiseVal')
    logduser = request.user.username
    logduseremail = request.user.email
    saveRegChoice = BookATestTable(username=logduser, email=logduseremail, registered="Yes", Available="No", language=getbkchoice)
    saveRegChoice.save()
    coutEntries = BookATestTable.objects.filter(username=logduser, language=getbkchoice).count()
    if coutEntries > 1:
        BookATestTable.objects.filter(username=logduser, language=getbkchoice).delete()
        saveRegChoice = BookATestTable(username=logduser, email=logduseremail, registered="Yes", Available="Yes", language=getbkchoice)
        saveRegChoice.save()
    return JsonResponse(getbkchoice, safe=False)

@login_required
def ManageUsers(request):
    return render(request, 'Protest/manageusers.html')
#add French Question and abswers
@login_required
def AddFrenchQuestionAnsAnswer(request):
    if request.method == 'POST':
        form = QuestionandanswersForm(request.POST)
        if form.is_valid():
            newQuestion = FrenchQuestionandanswers(language=request.POST['language'], section=request.POST['section'],
                          questionNumber=request.POST['questionNumber'], question=request.POST['question'],
                          AnsA=request.POST['AnsA'], AnsB=request.POST['AnsB'],AnsC=request.POST['AnsC'],AnsD=request.POST['AnsD'],
                          rightAnswer=request.POST['rightAnswer'])
            newQuestion.save()
            return redirect('viewqafrench')
    form = QuestionandanswersForm
    context = {'form' : form }
    return render(request, 'Protest/addfrenchquestionandanswer.html', context)

#add Kiswahili Questions and Aswers
@login_required
def AddSwahiliQuesionandAnswers(request):
    if request.method == 'POST':
        form = QuestionandanswersForm(request.POST)
        if form.is_valid():
            newQuestion = AddSwahiliQuestionAnsAnswers(language=request.POST['language'], section=request.POST['section'],
                          questionNumber=request.POST['questionNumber'], question=request.POST['question'],
                          AnsA=request.POST['AnsA'], AnsB=request.POST['AnsB'],AnsC=request.POST['AnsC'],AnsD=request.POST['AnsD'])
            newQuestion.save()
            return redirect('viewswahili')
    form = QuestionandanswersForm
    context = {'form' : form }
    return render(request, 'Protest/addSwahiliquestionandanswer.html', context)

#Add Chinise Questions and answers
@login_required
def AddMandarinQuestionAnsAnswers(request):
    if request.method == 'POST':
        form = QuestionandanswersForm(request.POST)
        if form.is_valid():
            newQuestion = MandarinQuestionandanswers(language=request.POST['language'], section=request.POST['section'],
                          questionNumber=request.POST['questionNumber'], question=request.POST['question'],
                          AnsA=request.POST['AnsA'], AnsB=request.POST['AnsB'],AnsC=request.POST['AnsC'],AnsD=request.POST['AnsD'])
            newQuestion.save()
            return redirect('viewchinese')
    form = QuestionandanswersForm
    context = {'form' : form }
    return render(request, 'Protest/addMandarinQuestionandans.html', context)


@login_required
def ViewEnglishQuestionAnswersGram_1(request):
    getQa = ProenglishQuestionsandanswers.objects.filter(language="English", section="Grammar1")
    title = "English Questions: Grammar 1"
    context = {'getQa' : getQa}
    return render(request, 'Protest/viewQuestionsGRm_1.html', context)

@login_required
def ViewEnglishQuestionAnswersGram_2(request):
    getQa = ProenglishQuestionsandanswers.objects.filter(language="English", section="Grammar2")
    title = "English Questions: Grammar 2"
    context = {'getQa' : getQa, 'title' : title}
    return render(request, 'Protest/viewQuestionsGRm_2.html', context)

@login_required
def ViewEnglishQuestionAnswersCompre(request):
    getQa = ProenglishQuestionsandanswers.objects.filter(language="English", section="READING COMPREHENSION")
    title = "English Questions: Reading Comprehention"
    context = {'getQa' : getQa, 'title' : title}
    return render(request, 'Protest/viewQuestionsredCompre.html', context)

@login_required
def ViewEnglishQuestionAnswersynm(request):
    getQa = ProenglishQuestionsandanswers.objects.filter(language="English", section="SYNONYMS")
    title = "English Questions: Synonyms"
    context = {'getQa' : getQa, 'title' : title}
    return render(request, 'Protest/viewQuestionsredsynms.html', context)

@login_required
def ViewEnglishQuestionAnswerAntoms(request):
    getQa = ProenglishQuestionsandanswers.objects.filter(language="English", section="Antonyms")
    title = "English Questions: Antonyms"
    context = {'getQa' : getQa, 'title' : title}
    return render(request, 'Protest/ViewEnglishQuestionAnswerAntoms.html', context)

@login_required
def ViewEnglishQuestionAnswerVocabulary(request):
    getQa = ProenglishQuestionsandanswers.objects.filter(language="English", section="Vocabulary")
    title = "English Vocabulary"
    context = {'getQa' : getQa, 'title' : title}
    return render(request, 'Protest/viewQuestionsVocabulary.html', context)

@login_required
def ViewEnglishQuestionAnswerPartsofSpeech(request):
    getQa = ProenglishQuestionsandanswers.objects.filter(language="English", section="PartsOfSpeech")
    title = "English Parts of Speech"
    context = {'getQa' : getQa, 'title' : title}
    return render(request, 'Protest/viewQuestionsPartsOfSpeech.html', context)

#function to dispaly english Questions and Answers dashboard
def EnglishQAdashboard(request):
    return render(request, 'Protest/enQAdashBoard.html')

#add func to filter questions so only french appear
@login_required
def ViewFrenchQuestionAnswers(request):
    getQa = FrenchQuestionandanswers.objects.filter(language='French')
    title = "French Questions"
    context = {'getQa' : getQa, 'title' : title}
    return render(request, 'Protest/viewQuestions.html', context)

@login_required
def ViewSwahiliQuestionAnswers(request):
    getQa = SwahiliQuestionandanswers.objects.filter(language="Swahili")
    title = "Swahili Questions"
    context = {'getQa' : getQa, 'title' : title}
    return render(request, 'Protest/viewQuestions.html', context)

@login_required
def ViewMandarinQuestionAnswers(request):
    getQa = MandarinQuestionandanswers.objects.filter(language="Mandarin")
    title = "Mandarin Questions"
    context = {'getQa' : getQa, 'title' : title}
    return render(request, 'Protest/viewQuestions.html', context)

@login_required
def Help(request):
    title = "LTCS Admin Help page"
    context = {'title' : title}
    return render(request, 'Protest/help.html', context)

#get registred useers andactivate their tests
@login_required
def getRegEnglishUsers(request):
    getRegEngUsers =  BookATestTable.objects.filter(language="English", registered="Yes")
    title = "Registerd English users"
    context = {'title' : title, 'getRegEngUsers' : getRegEngUsers}
    return render(request, 'Protest/regengusers.html', context)

def ActivateEnguser(request, username, language):
    BookATestTable.objects.filter(username=username, language=language).update(Available="Yes")
    redirect('getengregusers')
    return redirect('getengregusers')

def ClearEnguser(request, username, language):
    BookATestTable.objects.filter(username=username, language=language).update(Available="No")
    redirect('getengregusers')
    return redirect('getengregusers')

@login_required
def getRegSpanishUsers(request):
    getRegEspUsers =  BookATestTable.objects.filter(language="Spanish", registered="Yes")
    title = "Registerd Spanish users"
    context = {'title' : title, 'getRegEspUsers' : getRegEspUsers}
    return render(request, 'Protest/regespausers.html', context)

def ActivateSpanish(request, username, language):
    BookATestTable.objects.filter(username=username, language=language).update(Available="Yes")
    redirect('getespanishreguser')
    return redirect('getespanishreguser')

def ClearEspan(request, username, language):
    BookATestTable.objects.filter(username=username, language=language).update(Available="No")
    redirect('getespanishreguser')
    return redirect('getespanishreguser')

@login_required
def getRegFrenchUser(request):
    getRegFrenchUsers =  BookATestTable.objects.filter(language="French", registered="Yes")
    title = "Registerd French users"
    context = {'title' : title, 'getRegFrenchUsers' : getRegFrenchUsers}
    return render(request, 'Protest/regefrenchusers.html', context)

def ActivateFrench(request, username, language):
    BookATestTable.objects.filter(username=username, language=language).update(Available="Yes")
    redirect('getefrenchreguser')
    return redirect('getefrenchreguser')

def clearFrench(request, username, language):
    BookATestTable.objects.filter(username=username, language=language).update(Available="No")
    redirect('getefrenchreguser')
    return redirect('getefrenchreguser')

@login_required
def getRegChineseUser(request):
    getRegchineseUsers =  BookATestTable.objects.filter(language="Chinese", registered="Yes")
    title = "Registerd Chinese users"
    context = {'title' : title, 'getRegchineseUsers' : getRegchineseUsers}
    return render(request, 'Protest/regechineseusers.html', context)

def ActivateChinese(request, username, language):
    BookATestTable.objects.filter(username=username, language=language).update(Available="Yes")
    redirect('getechinesereguser')
    return redirect('getechinesereguser')

def clearChinese(request, username, language):
    BookATestTable.objects.filter(username=username, language=language).update(Available="No")
    redirect('getechinesereguser')
    return redirect('getechinesereguser')

@login_required
def getRegChichewaUser(request):
    getRegchichewaUsers =  BookATestTable.objects.filter(language="Chichewa", registered="Yes")
    title = "Registerd Chichewa users"
    context = {'title' : title, 'getRegchichewaUsers' : getRegchichewaUsers}
    return render(request, 'Protest/regechichewausers.html', context)

def ActivateChichewa(request, username, language):
    BookATestTable.objects.filter(username=username, language=language).update(Available="Yes")
    redirect('getechichewareguser')
    return redirect('getechichewareguser')

def clearChichewa(request, username, language):
    BookATestTable.objects.filter(username=username, language=language).update(Available="No")
    redirect('getechichewareguser')
    return redirect('getechichewareguser')

@login_required
def getRegTumbukaUser(request):
    getRegTumbukaUsers =  BookATestTable.objects.filter(language="Tumbuka", registered="Yes")
    title = "Registerd Chichewa users"
    context = {'title' : title, 'getRegTumbukaUsers' : getRegTumbukaUsers}
    return render(request, 'Protest/regetumbukausers.html', context)

def ActivateTumbuka(request, username, language):
    BookATestTable.objects.filter(username=username, language=language).update(Available="Yes")
    redirect('getetumbukareguser')
    return redirect('getetumbukareguser')

def clearTumbukaUser(request, username, language):
    BookATestTable.objects.filter(username=username, language=language).update(Available="No")
    redirect('getetumbukareguser')
    return redirect('getetumbukareguser')

@login_required
def getRegSwahiliUser(request):
    getRegSwahiliUsers =  BookATestTable.objects.filter(language="Swahili", registered="Yes")
    title = "Registerd Swahili users"
    context = {'title' : title, 'getRegSwahiliUsers' : getRegSwahiliUsers}
    return render(request, 'Protest/regeSwahiliusers.html', context)

def ActivateSwahili(request, username, language):
    BookATestTable.objects.filter(username=username, language=language).update(Available="Yes")
    redirect('geteswahilireguser')
    return redirect('geteswahilireguser')

def clearSwahili(request, username, language):
    BookATestTable.objects.filter(username=username, language=language).update(Available="No")
    redirect('geteswahilireguser')
    return redirect('geteswahilireguser')

@login_required
def getRegGermanUser(request):
    getRegGermanUsers =  BookATestTable.objects.filter(language="German", registered="Yes")
    title = "Registerd German users"
    context = {'title' : title, 'getRegGermanUsers' : getRegGermanUsers}
    return render(request, 'Protest/regegermanusers.html', context)

def ActivateGerman(request, username, language):
    BookATestTable.objects.filter(username=username, language=language).update(Available="Yes")
    redirect('getegermanreguser')
    return redirect('getegermanreguser')

def ClearGerman(request, username, language):
    BookATestTable.objects.filter(username=username, language=language).update(Available="No")
    redirect('getegermanreguser')
    return redirect('getegermanreguser')
