from django.urls import path
from .import views

urlpatterns = [
    path('home', views.goHomepage, name='home'),
    path('addqlandingpage', views.AddQuestionLandingPage, name='addqlandingpage'),

    path('addengqa', views.AddEnglishQuestionAnsAnswer, name='addengqa'),
    path('valqnumber', views.validate_Question_Number, name='valqnumber'),
    path('showenquestion/<enq_id>', views.ShowEngQuesion, name='showenquestion'),
    path('addfrench', views.AddFrenchQuestionAnsAnswer, name='addfrench'),
    path('addswahili',views.AddSwahiliQuesionandAnswers, name='addswahili'),
    path('addmandarin',views.AddMandarinQuestionAnsAnswers, name='addmandarin'),

    path('viewqaenglishgrammer1', views.ViewEnglishQuestionAnswersGram_1, name='viewqaenglishgrammer1'),
    path('viewqaenglishgrammer2', views.ViewEnglishQuestionAnswersGram_2, name='viewqaenglishgrammer2'),
    #reading and COMPREHENSION link
    path('viewqaenglishrcompr', views.ViewEnglishQuestionAnswersCompre, name='viewqaenglishrcompr'),
    path('viewqaenglishsynms', views.ViewEnglishQuestionAnswersynm, name='viewqaenglishsynms'),
    path('viewqaenglishantonm', views.ViewEnglishQuestionAnswerAntoms, name='viewqaenglishantonm'),
    path('viewqaengvocabulary', views.ViewEnglishQuestionAnswerVocabulary, name='viewqaengvocabulary'),
    path('viewqaengPartsofSpeech', views.ViewEnglishQuestionAnswerPartsofSpeech, name='viewqaengPartsofSpeech'),
    #route to EnglishQAdashboard function(englsih questions and answers )
    path('enqadash', views.EnglishQAdashboard, name="enqadash"),

    path('bookassment', views.BookAssessment, name="bookassment"),

    #links to book tests
    path('bookatest', views.BookAtest, name="bookatest"),
    # path('bookchinese', views.BookChinese, name="bookchinese"),
    # path('bookfrench', views.BookFrench, name="bookfrench"),
    # path('bookportguese', views.BookPorguese, name="bookportguese"),
    # path('bookswahili', views.BookEnglish, name="bookswahili"),

    path('availabletest', views.AvailableTest, name="availabletest"),
    #results dashboard
    path('getresults', views.ViewAssResults, name="getresults"),

    path('viewqafrench', views.ViewFrenchQuestionAnswers, name='viewqafrench'),
    path('viewswahili', views.ViewSwahiliQuestionAnswers, name='viewswahili'),
    path('viewchinese', views.ViewMandarinQuestionAnswers, name='viewchinese'),

    path('engtestgrammar1', views.TakeEnglishTestGrammar1, name='engtestgrammar1'),
    path('engtestgrammar2', views.TakeEnglishTestGrammar2, name='engtestgrammar2'),
    path('englreadcomp', views.EngREadingCompreh, name='englreadcomp'),
    path('englsynonyms', views.TakeEngSynonyms, name='englsynonyms'),
    path('englAntonyms', views.TakeEngAntonyms, name='englAntonyms'),
    path('englvocabulary', views.TakeEngVocaublary, name='englvocabulary'),
    path('englpartsofspeech', views.TakeEngPartsofSpeech, name='englpartsofspeech'),

    path('', views.index, name='index'),

    path('gradenglish', views.GradeEngish, name='gradenglish'),
    path('engscoregrm1', views.EnglishScoregrm1, name='engscoregrm1'),
    path('engscoregrm2', views.EnglishScoregrm2, name='engscoregrm2'),

    path('stdashboard', views.StudentDashboard, name='stdashboard'),
    #path('testlinks', views.TestLinks, name='testlinks'),
    #link for managing users and assessment test activation
    path('manageusers', views.ManageUsers, name='manageusers'),
    path('linktolangQA', views.GetAvailalbeTest, name='linktolangQA'),
    #get help
    path('help', views.Help, name='help'),

    #manage users
    path('getengregusers', views.getRegEnglishUsers, name='getengregusers'),
    path('activateEngUser/<username>/<language>', views.ActivateEnguser, name='activateEngUser'),
    path('clearEngUser/<username>/<language>', views.ClearEnguser, name='clearEngUser'),

    path('getespanishreguser', views.getRegSpanishUsers, name='getespanishreguser'),
    path('activatespanish/<username>/<language>', views.ActivateSpanish, name='activatespanish'),
    path('clearespan/<username>/<language>', views.ClearEspan, name='clearespan'),

    path('getefrenchreguser', views.getRegFrenchUser, name='getefrenchreguser'),
    path('activatefrench/<username>/<language>', views.ActivateFrench, name='activatefrench'),
    path('clearfrench/<username>/<language>', views.clearFrench, name='clearfrench'),

    path('getechinesereguser', views.getRegChineseUser, name='getechinesereguser'),
    path('activatechinese/<username>/<language>', views.ActivateChinese, name='activatechinese'),
    path('clearchinese/<username>/<language>', views.clearChinese, name='clearchinese'),

    path('getechichewareguser', views.getRegChichewaUser, name='getechichewareguser'),
    path('activatechichewa/<username>/<language>', views.ActivateChichewa, name='activatechichewa'),
    path('clearchichewa/<username>/<language>', views.clearChichewa, name='clearchichewa'),

    path('getetumbukareguser', views.getRegTumbukaUser, name='getetumbukareguser'),
    path('activatetumbuka/<username>/<language>', views.getRegTumbukaUser, name='activatetumbuka'),
    path('cleartumbuka/<username>/<language>', views.clearTumbukaUser, name='cleartumbuka'),

    path('geteswahilireguser', views.getRegSwahiliUser, name='geteswahilireguser'),
    path('activateswahili/<username>/<language>', views.ActivateSwahili, name='activateswahili'),
    path('clearswahili/<username>/<language>', views.clearSwahili, name='clearswahili'),

    path('getegermanreguser', views.getRegGermanUser, name='getegermanreguser'),
    path('activategerman/<username>/<language>', views.ActivateGerman, name='activategerman'),
    path('cleargerman/<username>/<language>', views.ClearGerman, name='cleargerman'),
]
